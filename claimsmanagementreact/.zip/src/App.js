// import { Routes, Route, Link } from "react-router-dom";
// // import Routers from './Routers';
// import Home from './core/Home';
// import Login from './auth/Login';
// import UserDashboard from './user/UserDashboard'

// function App() {
//   return (
//      <Routes>
//         <Route path="/" element={<Home />} />
//         <Route path="login" element={<Login />} />
//         <Route path="/user/dashboard" element={<UserDashboard/>}/>
//       </Routes>
//   );
// }

// export default App;
