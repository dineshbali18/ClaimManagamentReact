export const AUTH_API="http://authorizationservicepod1009-env.eba-admett7r.ap-south-1.elasticbeanstalk.com/authorization"
export const MEM_API="http://memberservice009pod1-env-1.eba-pppfxure.us-east-1.elasticbeanstalk.com/memberModule"
export const CLAIM_API="http://claim009pod1-env.eba-iqpu7kfc.ap-south-1.elasticbeanstalk.com/claimModule"
export const POLICY_API="http://policy009pod1-env.eba-eu3f6pqd.ap-south-1.elasticbeanstalk.com/policy"