export const AUTH_API="http://localhost:7000/authorization"
export const MEM_API="http://localhost:7001/memberModule"
export const CLAIM_API="http://localhost:7002/claimModule"